* To install, change to the directory where setup.py is located and type (python-2.3 or later needed):

    python setup.py install

* To run the regression tests, just go to the cheroot/test/ directory and type:

    nosetests -s ./

  Or to run individual tests type:

    nosetests -s test_foo.py
