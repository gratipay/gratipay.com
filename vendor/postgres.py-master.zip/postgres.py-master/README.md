postgres is a high-value abstraction over psycopg2

https://postgres-py.readthedocs.org/
