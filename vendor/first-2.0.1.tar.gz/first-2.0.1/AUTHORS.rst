Credits
=======

“first” is written and maintained by Hynek Schlawack and various contributors:

- Łukasz Langa
- Nick Coghlan
- Vincent Driessen
