from braintree.attribute_getter import AttributeGetter

class ThreeDSecureInfo(AttributeGetter):
    pass
