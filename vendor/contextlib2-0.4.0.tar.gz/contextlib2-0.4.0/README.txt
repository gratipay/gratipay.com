contextlib2 is a backport of the standard library's contextlib module to earlier Python versions.

It also serves as a real world proving ground for possible future enhancements to the standard library version.
