===============================
``parser``: Command-line parser
===============================

.. toctree::
    :glob:

    parser/*
