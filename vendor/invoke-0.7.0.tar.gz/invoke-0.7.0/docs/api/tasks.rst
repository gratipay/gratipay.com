==================================================
``tasks``: Task class & task-generating decorators
==================================================

.. automodule:: invoke.tasks
