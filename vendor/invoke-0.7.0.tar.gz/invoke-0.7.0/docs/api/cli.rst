=======================
``cli``: CLI entrypoint
=======================

.. automodule:: invoke.cli
