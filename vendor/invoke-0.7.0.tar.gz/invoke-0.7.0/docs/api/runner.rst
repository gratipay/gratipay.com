===================================
``Runner``: Executes shell commands
===================================

.. automodule:: invoke.runner
