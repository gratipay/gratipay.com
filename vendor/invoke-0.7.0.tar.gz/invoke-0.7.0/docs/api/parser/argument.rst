=================================
``Argument``: CLI arguments/flags
=================================

.. automodule:: invoke.parser.argument
