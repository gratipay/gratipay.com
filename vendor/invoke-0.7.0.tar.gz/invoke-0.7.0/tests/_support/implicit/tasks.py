from invoke.tasks import task


@task
def foo():
    print("Hm")
