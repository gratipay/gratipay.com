from invoke import task

@task
def mytask():
    pass
