Supported Platforms
===================

- Python 2.6
- Python 2.7
- Python 3.2
- Python 3.3
- PyPy
- Google App Engine
