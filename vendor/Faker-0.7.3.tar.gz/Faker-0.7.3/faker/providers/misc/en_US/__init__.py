from .. import Provider as MiscProvider


class Provider(MiscProvider):
    pass
