from .. import Provider as ProfileProvider


class Provider(ProfileProvider):
    pass
