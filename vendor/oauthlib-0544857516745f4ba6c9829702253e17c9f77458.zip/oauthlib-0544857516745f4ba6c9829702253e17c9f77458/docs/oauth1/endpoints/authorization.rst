Authorization
-------------

.. autoclass:: oauthlib.oauth1.AuthorizationEndpoint
    :members:
