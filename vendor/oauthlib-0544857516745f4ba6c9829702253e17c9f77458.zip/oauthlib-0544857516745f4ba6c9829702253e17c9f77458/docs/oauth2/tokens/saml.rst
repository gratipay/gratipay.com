===========
SAML Tokens
===========

Not yet implemented. Track progress in `GitHub issue 49`_.

.. _`GitHub issue 49`: https://github.com/idan/oauthlib/issues/49
