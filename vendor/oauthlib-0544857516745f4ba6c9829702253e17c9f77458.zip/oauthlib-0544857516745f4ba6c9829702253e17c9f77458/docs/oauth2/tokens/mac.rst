==========
MAC tokens
==========

Not yet implemented. Track progress in `GitHub issue 29`_. Might never be
supported depending on whether the work on the specification is resumed or not.

.. _`GitHub issue 29`: https://github.com/idan/oauthlib/issues/29
