LegacyApplicationClient
-----------------------

.. autoclass:: oauthlib.oauth2.LegacyApplicationClient
    :members:
