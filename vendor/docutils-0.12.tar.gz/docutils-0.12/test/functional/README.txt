This directory stores data files for functional tests.

Please see the documentation on `functional testing`__ for details.

__ ../../docs/dev/testing.html#functional
