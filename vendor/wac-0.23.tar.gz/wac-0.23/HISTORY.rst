.. :changelog:

History
-------

0.21 (2013-06-18)
++++++++++++++++++

* Require requests >= 1.2.3.

0.19 (2013-05-16)
++++++++++++++++++

* Allow requests version <= 1.1.0.

0.14 (2013-01-29)
++++++++++++++++++

* Pin requests version to less than 1.0 until we test it with requests > 1.0.

0.12 (2012-10-02)
++++++++++++++++++

* Fix ResourceCollection.filter.
* Add like and ilike filters.
* Minor pep8/formatting changes.

0.11 (2012-09-11)
++++++++++++++++++

* Fix config copy.

0.10 (2012-07-27)
++++++++++++++++++

* Python 2.6 compatibility.

0.9 (2012-07-25)
++++++++++++++++++

* Save serialization fix.

0.8 (2012-07-25)
++++++++++++++++++

* Pagination fixes.

0.7 (2012-07-20)
++++++++++++++++++

* Misc fixes.

0.3 (2012-05-28)
++++++++++++++++++

* Hope you like it.

0.2 (2012-05-01)
++++++++++++++++++

* Growing pains.

0.1 (2012-04-01)
++++++++++++++++++

* Its alive!
